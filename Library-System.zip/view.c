#include<stdio.h>
#include"view.h"
#include"control.h"
void mainMenu()
{
    int i;
    system("cls");


    printf("1)Book Management\n2)Member Management\n3)Borrow Management\n4)Administrative Actions\n5)Print Files\n6)Save Changes\n7)Exit\n");
    char n=choices('7');
    system("cls");
    switch(n)
    {
    case '1':
        bookManagement();
        break;
    case '2':
        memberManagement();
        break;
    case '3':
        borrowManagement();
        break;
    case '4':
        administartiveActions();
        break;
    case '5':
        printFiles();
        break;
    case '6':
        saveChanges();
        break;

    case '7':exitProgram();
    break;


    }

}
char choices(char x)
{
    char n;char *a=malloc(128);

    scanf("%s",a);
    n=a[0];
    while(n>x||n<'1'||strlen(a)>1)
    {   free(a);
    a=malloc(128);
        printf("please enter correct choice:\n");
        scanf("%s",a);
        n=a[0];

    }free(a);
    return n;
}
void bookManagement()
{
    printf("1)Insert\n2)search\n3)Add Copies\n4)Delete\n5)Edit\n6)Back\n");
    char n=choices('6');
    getchar();
    system("cls");
    switch(n)
    {
    case '1':
        insertBook();
        break;
    case '2':
        searchForBook();
        break;
    case '3':
        addCopies();
        break;
    case '4':
        deleteBook();

        break;
    case '5':
        editBook();

        break;
    case '6':
        mainMenu();
    }

}
void memberManagement()
{
    printf("1)register\n2)Remove\n3)Back\n");
    char n=choices('3');
    system("cls");
    switch(n)
    {
    case '1':
        registerMember();
        break;
    case '2':
        removeMember();
        break;
    case '3':
        mainMenu();
        break;
    }
}
void borrowManagement()
{
    printf("1)Borrow\n2)Return\n3)Back\n");
    char n=choices('3');
    switch(n)
    {
    case '1':
        borrowBook();
        break;
    case '2':
        returnBook();
        break;
    case '3':
        mainMenu();

    }
}
void administartiveActions()
{
    printf("1)Overdue\n2)Popular\n3)Back\n");
    char n=choices('3');
    switch(n)
    {
    case '1':
        overDue();
        break;
    case '2':
        popular();
        break;
    case '3':
        mainMenu();
    }
}
void saveChanges()
{
    printf("Are you sure you want to save\n");
    printf("1)Yes\n2)Back to main menu\n");
    char n=choices('2');
    getchar();
    system("cls");
    switch(n)
    {
    case '1':
        save(1);
        break;
    case '2':
        mainMenu();
        break;
    }
}
void printFiles()
{
    int i;
    printf("Which file do you want to print:\n");
    printf("1)Books file\n2)Members file\n3)Borrowing file\n4)Back:\n");
    char a[12],choice=choices('4');
    switch(choice)
    {
    case'1':

        printf("### Books ###\n");
        for(i=0; i<booklines; i++)
        {
            printf("%d- %s,%s,%s,%s,%d/%d/%d,%d,%d,%s\n",i+1,bookArray[i].Tittle,bookArray[i].Author,
                   bookArray[i].Publisher,bookArray[i].ISBN,bookArray[i].DateOFPublishing.Day,
                   bookArray[i].DateOFPublishing.Month,bookArray[i].DateOFPublishing.Year,
                   bookArray[i].NumberOFCopies,bookArray[i].AvalibaleNumberOfCopies,bookArray[i].Category);

        }

        printf("\n\nPress any key too return to the main menu:\n");
        a[12];
        scanf("%s",a);
        mainMenu();
        break;

    case'2':

        printf("### Members ###\n");
        for(i=0; i<memberLines; i++)
        {
            printf("%d- %s,%s,%d,%s,%s,%s,%s,%d,%s\n",i+1,memberArray[i].Lastname,memberArray[i].FirstName
                   ,memberArray[i].ID,memberArray[i].memberAddress.Bulding,memberArray[i].memberAddress.Street,
                   memberArray[i].memberAddress.City,memberArray[i].Phone,memberArray[i].Age,memberArray[i].Email);

        }

        printf("\n\nPress any key too return to the main menu:\n");
        a[12];
        scanf("%s",a);
        mainMenu();

        break;
    case'3':

        printf("### Borrowing file ###\n");
        for(i=0; i<borrowLines; i++)
        {
            printf("%d) %s,%d,%d/%d/%d,%d/%d/%d,%d/%d/%d\n",i+1,borrowingArray[i].borrowBook,borrowingArray[i].borrowID
                   ,borrowingArray[i].borrowingDat.Day,borrowingArray[i].borrowingDat.Month,borrowingArray[i].borrowingDat.Year,
                   borrowingArray[i].dueDat.Day,borrowingArray[i].dueDat.Month,borrowingArray[i].dueDat.Year
                   ,borrowingArray[i].returningDat.Day,borrowingArray[i].returningDat.Month,borrowingArray[i].returningDat.Year);
        }
        printf("\n\nPress any key too return to the main menu:\n");
        a[12];
        scanf("%s",a);
        mainMenu();

        break;
    case'5':
        mainMenu();
        break;
    }

}
void exitProgram()
{
    printf("1)Save and exit\n2)Exit without saving\n3)back\n");
    char n=choices('3');
    switch(n)
    {
    case '1':
        save(0);
        system("cls");
        printf("Thanks for using our library system");

        break;
    case '2':
        system("cls");
        printf("Thanks for using our library system");
        break;
    case '3':
        mainMenu();
        break;

    }}


