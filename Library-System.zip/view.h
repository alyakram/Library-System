
void mainMenu();
char choices(char);
void bookManagement();
void memberManagement();
void borrowManagement();
void administartiveActions();
void saveChanges();
void exitProgram();
void borrowBook();
void printFiles();
