#include "control.h"
#include<stdio.h>
#include<string.h>
#include <stdio.h>
#include<unistd.h>
Book *bookArray;


void insertBook()
{
    int i,flag=0;

    Book b;
    char *tittle=malloc(256);
    printf("Please enter the book name:\n");

    gets(tittle);
    b.Tittle=malloc(strlen(tittle)+1);
    strcpy(b.Tittle,tittle);
    free(tittle);


    char *author=malloc(256);
    printf("Please enter the book's Author:\n");
    gets(author);
    b.Author=malloc(strlen(author)+1);
    strcpy(b.Author,author);
    free(author);

    char *publ=malloc(256);
    printf("Please enter the book's publisher:\n");
    gets(publ);
    b.Publisher=malloc(strlen(publ)+1);
    strcpy(b.Publisher,publ);
    free(publ);

    printf("please enter the book's ISBN :\n");
    char*currentISBN=malloc(56);
    currentISBN=isbnValidity(currentISBN);
    flag=isbnLocation(currentISBN);

    while(flag!=-1)
    {
        printf("This ISBN already exist\nPlease enter new ISBN:\n");
        currentISBN=realloc(currentISBN,56);
        currentISBN=isbnValidity(currentISBN);
        flag=isbnLocation(currentISBN);

    }
    strcpy(b.ISBN,currentISBN);
    free(currentISBN);


    char*date=malloc(128);
    printf("please enter the date int the form of dd/mm/yyyy :\n");
    getchar();
    gets(date);
    sscanf(date,"%d/%d/%d",&b.DateOFPublishing.Day,&b.DateOFPublishing.Month,&b.DateOFPublishing.Year);
    free(date);

    printf("Enter number of copies\n");
    int  numb;
    scanf("%d",&numb);
    while(numb<0){
        printf("Please enter positive number:\n");
        scanf("%d",&numb);
    }
    b.NumberOFCopies=numb;


    printf("Enter number of available copies\n");
    int temp;
    scanf("%d",&temp);
    while(temp>b.NumberOFCopies||temp<0)
    {
        printf("Please enter correct available number of copies:\n");
        scanf("%d",&temp);
    }
    b.AvalibaleNumberOfCopies=temp;


    printf("Enter category\n");
    char* type= malloc(128);
    getchar();
    gets(type);
    b.Category=malloc(strlen(type)+1);
    strcpy(b.Category,type);
    free(type);

    Book currentBookArray[booklines];
    for(i=0; i<booklines; i++)
    {

        currentBookArray[i]=bookArray[i];
    }
    booklines++;
    bookArray=realloc(bookArray,sizeof(Book)*booklines);
    for(i=0; i<booklines-1; i++)
    {
        printf("***");
        bookArray[i]=currentBookArray[i];
    }
    printf("%d",i);
    bookArray[i]=b;
    free(currentBookArray);

    system("cls");
    printf("1)Insert another book\n2)Return to MainMenu:\n");
    char choice=choices('2');
    switch(choice)
    {
    case '1':
        getchar();
        insertBook();
    case '2':
        mainMenu();
    }
}



void searchForBook()
{
    printf("Search by\n1)Book's tittle\n2)Author's name\n3)ISBN\n4)Category)\n5)Back\n");
    char choice=choices('5');
    system("cls");
    char *searching=malloc(128);
    char *temp=malloc(128);
    char *result;
    getchar();
    int i=0,flag=0;
    switch(choice)
    {
    case '1':
    {
        printf("please enter the book's tittle:\n");
        gets(searching);
        int j,flag;
        searching=lowerString(searching,searching);
        for(i=0; i<booklines; i++)
        {
            temp=lowerString(bookArray[i].Tittle,temp);
            result=strstr(temp,searching);

            if(result)
            {
                printf("Book:%s\nAuthor:%s\nCategory:%s\n",bookArray[i].Tittle,bookArray[i].Author,bookArray[i].Category);
                flag=1;
            }

        }
        free(temp);
        free(searching);
        if(!flag)
            printf("The book is not found\n");

        printf("1)Search for another book\n2)Return to MainMenu:\n");
        char choice=choices('2');
        switch(choice)
        {
        case '1':
            system("cls");
            searchForBook();
            break;
        case '2':
            mainMenu();
            break;
        }
    }
    break;


    case '2':
    {
        printf("please enter the book's Author:\n");
        gets(searching);
        searching=lowerString(searching,searching);
        for(i=0; i<booklines; i++)
        {
            temp=lowerString(bookArray[i].Author,temp);
            result=strstr(temp,searching);
            if(result)
            {
                printf("Book:%s\nAuthor:%s\nCategory:%s\n",bookArray[i].Tittle,bookArray[i].Author,bookArray[i].Category);
                flag=1;
            }

        }
        if(!flag)
            printf("The book is not found\n");

        printf("1)Search for another book\n2)Return to MainMenu:\n");
        char choice=choices('2');
        switch(choice)
        {
        case '1':
            system("cls");
            searchForBook();
            break;
        case '2':
            mainMenu();
            break;
        }
    }
    break;
    case '3':
        printf("please enter the book's ISBN:\n");
        gets(searching);
        flag=isbnLocation(searching);
        if(flag==-1)
            printf("The book is not found\n\n");
            else
               printf("Book:%s\nAuthor:%s\nCategory:%s\n",bookArray[flag].Tittle,bookArray[flag].Author,bookArray[flag].Category);

        printf("1)Search for another book\n2)Return to MainMenu:\n");
        char choice=choices('2');
        switch(choice)
        {
        case '1':
            system("cls");
            searchForBook();
            break;
        case '2':
            mainMenu();
            break;
        }

        break;


    case '4':
    {
        printf("please enter the book's Category:\n");
        gets(searching);
        searching=lowerString(searching,searching);
        for(i=0; i<booklines; i++)
        {

            temp=lowerString(bookArray[i].Category,temp);
            result=strstr(temp,searching);
            if(result)
            {
                printf("Book:%s\nAuthor:%s\nCategory:%s\n",bookArray[i].Tittle,bookArray[i].Author,bookArray[i].Category);
                flag=1;
            }

        }
        if(flag==0)
            printf("The book is not found\n");
        printf("1)Search for another book\n2)Return to MainMenu:\n");
        char choice=choices('2');
        switch(choice)
        {
        case '1':
            system("cls");
            searchForBook();
            break;
        case '2':
            mainMenu();
            break;
        }

    }
    break;
    case '5':
        mainMenu();

    }




}
void addCopies()
{
    int flag=0;
    printf("Please enter the book ISBN:\n");
    char *isbn=malloc(56);
    isbn=isbnValidity(isbn);
    int noOfCopies,i;

    i=isbnLocation(isbn);
    if(i==-1)
    {
        system("cls");
        printf("The book is not found:\n");
        printf("1)Enter ISBN again\n2)Return to MainMenu:\n");
        char choice=choices();
        switch(choice)
        {
        case '1':
            system("cls");
            addCopies();
            break;
        case '2':
            free(isbn);
            mainMenu();
            break;
        }
    }
    else
    {
        system("cls");
        do
        {
            printf("Please enter the number of new copies you want to add:\n");
            scanf("%d",&noOfCopies);
        }
        while(noOfCopies<0);
        printf("Copies is added\n");

    }
    free(isbn);
    bookArray[i].AvalibaleNumberOfCopies+=noOfCopies;
    bookArray[i].NumberOFCopies+=noOfCopies;
    mainMenu();

}

void deleteBook()
{
    system("cls");
    printf("Please enter the book's ISBN:\n");
    char *isbn=malloc(56);
    isbn=isbnValidity(isbn);
    int i,location,j=0,flag=0;
    Book currentBookArray[booklines];
    for(i=0; i<booklines; i++)
    {
        if(!strcasecmp(bookArray[i].ISBN,isbn))
        {
            location=i;
            flag=1;
        }


        currentBookArray[i]=bookArray[i];
    }
    free(isbn);
    if(flag)
    {
        free(bookArray);
        booklines--;
        bookArray=malloc(sizeof(Book)*booklines);
        for(i=0; i<booklines+1; i++)
        {
            if(i!=location)
            {
                bookArray[j]=currentBookArray[i];
                j++;
            }
        };
        system("cls");
        printf("1)Delete another book\n2)Return to MainMenu:\n");
        char choice=choices('2');
        switch(choice)
        {
        case '1':
            deleteBook();
            break;
        case '2':
            mainMenu();
            break;
        }
    }
    else
    {

        printf("The book is not found\n");
        printf("1)Enter ISBN again\n2)Return to MainMenu:\n");
        char choice=choices('2');
        switch(choice)
        {
        case '1':
            deleteBook();
            break;
        case '2':
            mainMenu();
            break;
        }
    }
}
void editBook()
{   int i;
    printf("Please enter the book's ISBN:\n");
    char*isbn=malloc(56);
    char*temp=malloc(128);
    isbn=isbnValidity(isbn);
    i=isbnLocation(isbn);


    free(isbn);
    if(i!=-1)
    {
        printf("What do you want to edit\n1)Books's tittle\n2)Book's Author\n3)Book'sPublisher\n4)Book's Dat of publishing\n5)category\n6)Enter ISBN again\n7)Back to MainMenu\n");
        char choice=choices('7');
        getchar();
        switch(choice)
        {
        case '1':
            printf("please enter the new tittle:\n");
            gets(temp);
            bookArray[i].Tittle=malloc(strlen(temp)+1);
            strcpy(bookArray[i].Tittle,temp);
            free(temp);
            mainMenu();
            break;
        case '2':
            printf("Please enter the new Author's name:\n");
            gets(temp);
            bookArray[i].Author=malloc(strlen(temp)+1);
            strcpy(bookArray[i].Author,temp);
            free(temp);
            mainMenu();
            break;
        case '3':
            printf("Please enter the new Publisher's name:\n");
            gets(temp);
            bookArray[i].Publisher=malloc(strlen(temp)+1);
            strcpy(bookArray[i].Publisher,temp);
            free(temp);
            mainMenu();
            break;
        case '4':
            printf("Please enter the new Date of publishing name in the form of dd/mm/yyyy:\n");
            gets(temp);
            sscanf(temp,"%d/%d/%d",&bookArray[i].DateOFPublishing.Day,&bookArray[i].DateOFPublishing.Month
                   ,&bookArray[i].DateOFPublishing.Year);
            free(temp);
            mainMenu();
            break;
        case '5':
            printf("Please enter the new category:\n");
            gets(temp);
            bookArray[i].Category=malloc(strlen(temp)+1);
            strcpy(bookArray[i].Category,temp);
            free(temp);
            mainMenu();
            break;
        case '6':
            editBook();
            break;
        case '7':
            free(temp);
            mainMenu();
            break;

        }
    }
    else
    {
        free(temp);
        printf("The book is not found\n\n");
        printf("1)Enter ISBN again\n2)Return to MainMenu:\n");
        char n=choices('2');
        switch(n)
        {
        case '1':
            system("cls");
            editBook();
            break;
        case '2':
            mainMenu();
            break;
        }
    }
}
void registerMember()
{
    MemberInf m;
    printf("please enter the member's Last Name:\n");
    char*MInformation=malloc(128);
    getchar();
    gets(MInformation);
    m.Lastname=malloc(strlen(MInformation)+1);
    strcpy(m.Lastname,MInformation);


    printf("please enter the member's First Name:\n");
    MInformation=realloc(MInformation,128);
    gets(MInformation);
    m.FirstName=malloc(strlen(MInformation)+1);
    strcpy(m.FirstName,MInformation);

    printf("Please enter the member's ID:\n");
    int id,i,flag=0;
    scanf("%d",&id);

    for(i=0;i<memberLines;i++)
    {
        if(id==memberArray[i].ID)
        {
            flag=1;break;
        }
    }
    while(flag==1)
    {   flag=0;
        printf("This ID Already exist\nPlease enter new ID:\n");
        scanf("%d",&id);
        for(i=0;i<memberLines;i++)
    {
        if(id==memberArray[i].ID)
        {
            flag=1;break;
        }
    }
    }

    m.ID=id;


    printf("Please enter the member's address in the form of Building,Street,City:\n");
    MInformation=realloc(MInformation,128);
    getchar();
    gets(MInformation);
    char*currentBuilding=malloc(64);
    char*currentStreet=malloc(64);
    char*currentCity=malloc(64);
    sscanf(MInformation,"%[^,]%*c%[^,]%*c%s",currentBuilding,currentStreet,currentCity);

    m.memberAddress.Bulding=malloc(strlen(currentBuilding)+1);
    m.memberAddress.Street=malloc(strlen(currentStreet)+1);
    m.memberAddress.City=malloc(strlen(currentCity)+1);

    strcpy(m.memberAddress.Bulding,currentBuilding);
    strcpy(m.memberAddress.Street,currentStreet);
    strcpy(m.memberAddress.City,currentCity);
    free(currentBuilding);
    free(currentStreet);
    free(currentCity);

    printf("please enter the phone number:\n");
    gets(m.Phone);

    printf("Please enter the member's age:\n");
    scanf("%d",&m.Age);
    getchar();
    printf("Please enter the member's Email:\n");
    MInformation=realloc(MInformation,128);
    gets(MInformation);
    m.Email=malloc(strlen(MInformation)+1);
    strcpy(m.Email,MInformation);
    free(MInformation);


    MemberInf currentArray[memberLines];

    for(i=0; i<memberLines; i++)
    {
        currentArray[i]=memberArray[i];
    }
    memberLines++;
    memberArray=realloc(memberArray,sizeof(MemberInf)*memberLines);
    for(i=0; i<memberLines-1; i++)
    {
        memberArray[i]=currentArray[i];
    }

    memberArray[i]=m;
    system("cls");
    printf("1)Insert another member\n2)Return to MainMenu:\n");
    char choice=choices('2');
    switch(choice)
    {
    case '1':
        registerMember();
        break;
    case '2':
        mainMenu();
        break;
    }

}
void removeMember()
{   int id,flag=0,i,location,j=0;
    printf("Please enter the member's ID:\n");
    scanf("%d",&id);
    for(i=0;i<memberLines;i++)
    {
        if(memberArray[i].ID==id){
           location=i;flag=1;break;}
    }
    if(flag==0)
    {
        printf("This ID does not exist:\n");
        printf("Press any key to return to the MainMenu:\n");
        char a[12];
        scanf("%s",a);
        mainMenu();
    }
    else
    {
        for(i=0;i<borrowLines;i++)
        {
            if(borrowingArray[i].borrowID==id&&borrowingArray[i].returningDat.Day==0){
                flag=-1;break;}
        }
    }
    if(flag==-1)
    {

        printf("Cannot delete this member\nThere is a book with this member:\n");
        printf("Press any key to return to the MainMenu:\n");
        char a[12];
        scanf("%d",a);
        mainMenu();
    }
    else
    {
        MemberInf currentArray[memberLines];
    for(i=0; i<memberLines;i++)
    {
        currentArray[i]=memberArray[i];
    }

        free(memberArray);
        memberLines--;
        memberArray=malloc(sizeof(MemberInf)*memberLines);

        for(i=0; i<memberLines+1; i++)
        {
            if(i!=location)
            {
                memberArray[j]=currentArray[i];
                j++;
            }
        }
        system("cls");
        printf("Member is deleted:\n");
        printf("1)Delete another member\n2)Return to MainMenu:\n");
        char choice=choices('2');
        switch(choice)
        {
        case '1':
            deleteBook();
            break;
        case '2':
            mainMenu();
            break;
        }
    }

}
void borrowBook()
{
    int i,flag=0,j,flag2=0,numberOfBorrowedBooks=0;
    int id,location;
    printf("please enter the book's ISBN:\n");
    char *currentISBN=malloc(28);
    gets(currentISBN);
    currentISBN=isbnValidity(currentISBN);
    i=isbnLocation(currentISBN);
    free(currentISBN);
if(i!=-1){
    if(bookArray[i].AvalibaleNumberOfCopies!=0){
            borrowingInf inf;
    printf("Please enter the member's ID:\n");
    scanf("%d",&id);
    for(j=0;j<memberLines;j++){
        if(id==memberArray[j].ID){
            flag2=1;
            break;
        }
    }
    for(j=0;j<borrowLines;j++){
        if(id==borrowingArray[j].borrowID&&borrowingArray[j].returningDat.Day==0){
        numberOfBorrowedBooks++;

        }
        if(numberOfBorrowedBooks==3)
        {   flag2=-1;
            break;
        }

    }
    if(flag2==1){

    bookArray[i].AvalibaleNumberOfCopies--;
    strcpy(inf.borrowBook,bookArray[i].ISBN);
    inf.borrowID=id;

    time_t timer;
    struct tm* tm_info;
    char day[3];
    char month[3];
    char year[5];
    time(&timer);
    tm_info = localtime(&timer);
    strftime(day, 3, "%d", tm_info);
    strftime(month, 3, "%m", tm_info);
    strftime(year, 5, "%Y", tm_info);

    char date[30];
    sprintf(date,"%s/%s/%s",day,month,year);

    dateAdding(date,&inf.dueDat.Day,&inf.dueDat.Month,&inf.dueDat.Year);


    sscanf(date,"%d/%d/%d",&inf.borrowingDat.Day,&inf.borrowingDat.Month,&inf.borrowingDat.Year);
    inf.returningDat.Day=inf.returningDat.Month=inf.returningDat.Year=0;


     borrowingInf currentArray[borrowLines];
    for(i=0; i<borrowLines; i++)
    {

        currentArray[i]=borrowingArray[i];
    }
    borrowLines++;
    borrowingArray=realloc(borrowingArray,sizeof(borrowingInf)*borrowLines);
    for(i=0; i<borrowLines-1; i++)
    {
        borrowingArray[i]=currentArray[i];
    }
    borrowingArray[i]=inf;
    free(currentArray);

    printf("1)Borrow another book\n2)Return to the MainMenu:\n");
    char choice=choices('2');
    switch(choice){
        case '1':borrowBook();break;
        case '2':mainMenu();break;


    }

    }  else if(flag2==-1)
    {
        printf("The member has 3 books,Cannot borrow more than 3 books at the same time:\n");
        printf("press any key to return th the MainMenu:\n");
        char a[12];
        getchar();
        gets(a);
        mainMenu();
    }
        else if(flag2==0){
            printf("This ID does not exist!\n ");
            printf("\n1)Register a new member\n2)MainMenu:\n");
            char choice=choices('2');
            switch(choice){
                case '1':registerMember();break;
                case '2':mainMenu();break;
            }}
    }
    else{ printf("There is no available number of copies\n");
           printf("1)Borrow another book\n2)Return to the MainMenu:\n");

           char choice=choices('2');
           switch(choice){
            case'1':borrowBook();break;
            case'2':mainMenu();break;
           }


    }
}
else{
    printf("The book is not found\n\n1)Borrow another book\n2)Return to the MainMenu:\n");
    char choice=choices('2');
    switch(choice){
        case '1':borrowBook();break;
        case '2':mainMenu();break;


    }}}
void returnBook()
{
    time_t timer;
    struct tm* tm_info;
    char day[3];
    char month[3];
    char year[5];
    time(&timer);
    tm_info = localtime(&timer);
    strftime(day, 3, "%d", tm_info);
    strftime(month, 3, "%m", tm_info);
    strftime(year, 5, "%Y", tm_info);

    char *date=malloc(128);
    int d,m,y;

    sprintf(date,"%s/%s/%s",day,month,year);
    sscanf(date,"%d/%d/%d",&d,&m,&y);

    free(date);

    int id,location,i,flag=0;
    char*isbn=malloc(128);

    printf("Please enter the member's ID:\n");
    scanf("%d",&id);

    printf("please enter the book's ISBN:\n");
    gets(isbn);
    isbnValidity(isbn);
    location=isbnLocation(isbn);

    for(i=0;i<borrowLines;i++){
        if(id==borrowingArray[i].borrowID&&!strcmp(isbn,borrowingArray[i].borrowBook)){
                printf("%s\n",borrowingArray[i].borrowBook);
                borrowingArray[i].returningDat.Day=d;
                borrowingArray[i].returningDat.Month=m;
                borrowingArray[i].returningDat.Year=y;
                bookArray[location].AvalibaleNumberOfCopies++;
                flag=1;
                break;

        }
    }free(isbn);
    if(flag==1){

    printf("1)Returning another book\n2)MainMenu:\n");
    char choice=choices('2');
    switch(choice){
        case '1':returnBook();break;
        case '2':mainMenu();break;
    }}
    else {
        printf("There is no book with this ISBN has been borrowed by this member:\n");
        printf("1)Enter ID and ISBN again\n2)Back to the MainMenu:\n");

        char choice=choices('2');
        switch(choice){
            case'1':returnBook();break;
            case'2':mainMenu();break;
        }
    }
}

void save(int a)
{
    FILE *F =fopen("members.txt","w");
    FILE *B =fopen("books.txt","w");
    FILE *J =fopen("borrowingfile.txt","w");
    int i=0;
    for(i=0;i<memberLines;i++){
                fprintf(F,"%s,%s,%d,%s,%s,%s,%s,%d,%s\n",memberArray[i].Lastname,memberArray[i].FirstName
               ,memberArray[i].ID,memberArray[i].memberAddress.Bulding,memberArray[i].memberAddress.Street,
               memberArray[i].memberAddress.City,memberArray[i].Phone,memberArray[i].Age,memberArray[i].Email);

    }
    for(i=0;i<booklines;i++){
        fprintf(B,"%s,%s,%s,%s,%d/%d/%d,%d,%d,%s\n",bookArray[i].Tittle,bookArray[i].Author,
               bookArray[i].Publisher,bookArray[i].ISBN
               ,bookArray[i].DateOFPublishing.Day,bookArray[i].DateOFPublishing.Month,
               bookArray[i].DateOFPublishing.Year,bookArray[i].NumberOFCopies,
               bookArray[i].AvalibaleNumberOfCopies,bookArray[i].Category);}
                              for(i=0;i<borrowLines;i++){
                fprintf(J,"%s,%d,%d/%d/%d,%d/%d/%d,%d/%d/%d\n",borrowingArray[i].borrowBook,borrowingArray[i].borrowID
                   ,borrowingArray[i].borrowingDat.Day,borrowingArray[i].borrowingDat.Month,borrowingArray[i].borrowingDat.Year,
                   borrowingArray[i].dueDat.Day,borrowingArray[i].dueDat.Month,borrowingArray[i].dueDat.Year
                   ,borrowingArray[i].returningDat.Day,borrowingArray[i].returningDat.Month,borrowingArray[i].returningDat.Year);

               }


fclose(F);
fclose(B);
fclose(J);
if(a==1){

mainMenu();}

}
void popular()
{
    Popular *popularArray=malloc(booklines*sizeof(Popular));
    int i,j;
    for(i=0;i<booklines;i++){
        strcpy(popularArray[i].isbn,bookArray[i].ISBN);
        popularArray[i].numberOfBorrows=0;
    }
    for(i=0;i<booklines;i++){
        for(j=0;j<borrowLines;j++)
        if(!strcmp(popularArray[i].isbn,borrowingArray[j].borrowBook))
            popularArray[i].numberOfBorrows++;
            }
        for(i=0;i<booklines;i++){
            for(j=0;j<booklines-1-i;j++)
            if(popularArray[j].numberOfBorrows<popularArray[j+1].numberOfBorrows){
                Popular temp;
                temp=popularArray[j];
                popularArray[j]=popularArray[j+1];
                popularArray[j+1]=temp;
            }

        }
        for(i=0;i<5;i++){int location;
            location=isbnLocation(popularArray[i].isbn);
            printf("%d-%s\n",i+1,bookArray[location].Tittle);
        }
        free(popularArray);
        printf("Please press any key to return to MainMenu:\n");

        char a[12];
        scanf("%s",a);
        mainMenu();



}

void overDue()
{
    time_t timer;
    struct tm* tm_info;
    char day[3];
    char month[3];
    char year[5];
    time(&timer);
    tm_info = localtime(&timer);
    strftime(day, 3, "%d", tm_info);
    strftime(month, 3, "%m", tm_info);
    strftime(year, 5, "%Y", tm_info);

    char *duedate=malloc(56);
    char *today=malloc(56);
    int i,flag;

    printf("ISBN\t\tMember's ID\tBorrowing date\tDue date\n\n");
    sprintf(today,"%s/%s/%s",day,month,year);

    for(i=0;i<borrowLines;i++)
    {
        if(borrowingArray[i].returningDat.Day==0)
        {
           sprintf(duedate,"%d/%d/%d",borrowingArray[i].dueDat.Day,borrowingArray[i].dueDat.Month,borrowingArray[i].dueDat.Year);

           flag=dateCompare(today,duedate);


        if(flag!=2)
        {

            printf("%s\t %d\t\t%d/%d/%d\t%d/%d/%d\n\n",borrowingArray[i].borrowBook,borrowingArray[i].borrowID,borrowingArray[i].borrowingDat.Day
                   ,borrowingArray[i].borrowingDat.Month,borrowingArray[i].borrowingDat.Year,borrowingArray[i].dueDat.Day,
                   borrowingArray[i].dueDat.Month,borrowingArray[i].dueDat.Year);
        }}
    }

  printf("\n\nPress any key to return to the main menu:\n");
  char a[13];
  scanf("%s",a);
  mainMenu();
}


int bookLinesCounter()
{
    FILE *f=fopen("books.txt","r");
    int  counter=0;
    char a[256];
    while(!feof(f))
    {
        fgets(a,256,f);
        counter++;
    }
    fclose(f);
    return --counter;
}
int memberLinesCounter()
{
    FILE *f=fopen("members.txt","r");
    int  counter=0;
    char a[256];
    while(!feof(f))
    {
        fgets(a,256,f);
        counter++;
    }
    fclose(f);
    return --counter;
}
int borrowingLinesCounter()
{
    FILE *f=fopen("borrowingFile.txt","r");
    int  counter=0;
    char a[256];
    while(!feof(f))
    {
        fgets(a,256,f);
        counter++;
    }
    fclose(f);
    return --counter;
}
void readFile()
{
    booklines =bookLinesCounter();
    bookArray = malloc(sizeof(Book)*booklines);

    books =malloc((booklines)*(sizeof(Book)));
    bookArray = books;
    int i=0;
    FILE*F=fopen("books.txt","r");
    while(!feof(F))
    {

        char *buffer=(char *)malloc(256);
        fgets(buffer,256,F);
        if(i<booklines)
        {
            char *currentTitle = malloc(128);
            char*currentAuthor=malloc(128);
            char*currentPublisher=malloc(128);
            char*currentCategory=malloc(128);

            sscanf(buffer,"%[^,]%*c%[^,]%*c%[^,]%*c%[^,]%*c%d/%d/%d,%d,%d,%[^,\n]%*c",currentTitle,currentAuthor,
                   currentPublisher,books[i].ISBN,&books[i].DateOFPublishing.Day,&books[i].DateOFPublishing.Month,
                   &books[i].DateOFPublishing.Year,&books[i].NumberOFCopies,&books[i].AvalibaleNumberOfCopies,currentCategory);

            books[i].Tittle = malloc(strlen(currentTitle)+1);
            books[i].Author=malloc(strlen(currentAuthor)+1);
            books[i].Publisher=malloc(strlen(currentPublisher)+1);
            books[i].Category=malloc(strlen(currentCategory)+1);
            strcpy(books[i].Tittle,currentTitle);
            strcpy(books[i].Author,currentAuthor);
            strcpy(books[i].Publisher,currentPublisher);
            strcpy(books[i].Category,currentCategory);

            free(currentTitle);
            free(currentAuthor);
            free(currentPublisher);
            free(currentCategory);

        }
        free(buffer);
        i++;


    }
    fclose(F);


}
void readMembersFile()
{

    memberLines=memberLinesCounter();
    memberArray = malloc(sizeof(MemberInf)*memberLines);

    int i=0;
    FILE*Fm=fopen("members.txt","r");

    while(!feof(Fm))
    {
        char *buffer=(char *)malloc(256);
        fgets(buffer,256,Fm);

        if(i<memberLines)
        {

            char t[30];
            char *currentFirstName = malloc(128);
            char*currentLastName=malloc(128);
            char*currentEmail=malloc(128);
            char*currentBuilding=malloc(128);
            char*currentStreet=malloc(128);
            char*currentCity=malloc(128);


            sscanf(buffer,"%[^,]%*c%[^,]%*c%d,%[^,]%*c%[^,]%*c%[^,]%*c%[^,]%*c%d,%[^,\n]%*c",currentLastName,currentFirstName
                   ,&memberArray[i].ID,currentBuilding,currentStreet,currentCity,memberArray[i].Phone,&memberArray[i].Age,currentEmail);

            memberArray[i].Lastname=malloc(strlen(currentLastName)+1);
            memberArray[i].FirstName=malloc(strlen(currentFirstName)+1);
            memberArray[i].Email=malloc(strlen(currentEmail)+1);
            memberArray[i].memberAddress.Bulding=malloc(strlen(currentBuilding)+1);
            memberArray[i].memberAddress.Street=malloc(strlen(currentStreet)+1);
            memberArray[i].memberAddress.City=malloc(strlen(currentCity)+1);

            strcpy(memberArray[i].Lastname,currentLastName);
            strcpy(memberArray[i].FirstName,currentFirstName);
            strcpy(memberArray[i].Email,currentEmail);
            strcpy(memberArray[i].memberAddress.Bulding,currentBuilding);
            strcpy(memberArray[i].memberAddress.Street,currentStreet);
            strcpy(memberArray[i].memberAddress.City,currentCity);



            free(currentLastName);
            free(currentFirstName);
            free(currentEmail);
            free(currentBuilding);
            free(currentStreet);
            free(currentCity);

        }

        free(buffer);

        i++;


    }
    fclose(Fm);


}
void readBorrowingFile()
{
    borrowLines=borrowingLinesCounter();
    borrowingArray = malloc(sizeof(borrowingInf)*borrowLines);
    int i=0;
    FILE*Fb=fopen("borrowingFile.txt","r");
    while(!feof(Fb))
    {
        char *buffer=(char *)malloc(256);
        fgets(buffer,256,Fb);
        if(i<borrowLines)
        {
            sscanf(buffer,"%[^,]%*c%d,%d/%d/%d,%d/%d/%d,%d/%d/%d/n",borrowingArray[i].borrowBook,&borrowingArray[i].borrowID
                   ,&borrowingArray[i].borrowingDat.Day,&borrowingArray[i].borrowingDat.Month,&borrowingArray[i].borrowingDat.Year,
                   &borrowingArray[i].dueDat.Day,&borrowingArray[i].dueDat.Month,&borrowingArray[i].dueDat.Year,&borrowingArray[i].returningDat.Day
                   ,&borrowingArray[i].returningDat.Month,&borrowingArray[i].returningDat.Year);


        }
        free(buffer);
        i++;
    }
    fclose(Fb);


}

char *lowerString(char*original,char*returened)
{
    int i;
    for(i=0; i<=strlen(original); i++)
        returened[i]=tolower(original[i]);

    return returened;

}
char *isbnValidity(char*isbn)
{
    char*currentISBN=malloc(56);
    gets(currentISBN);
    while(strlen(currentISBN)!=13)
    {
        printf("Please enter ISBN correct :\n");
        gets(currentISBN);
    }
    strcpy(isbn,currentISBN);
    free(currentISBN);
    return isbn;
}

int isbnLocation(char*isbn)
{
    int i,flag=-1;
for(i=0;i<booklines;i++)
{
        if(!strcmp(bookArray[i].ISBN,isbn))
        {
            flag=1;break;
        }

}
if(flag!=-1)
    return i;
else return flag;

}

void dateAdding(char*orignalDate,int*d,int*m,int*y)
{
     int day,month,year;
    sscanf(orignalDate,"%d/%d/%d",&day,&month,&year);
    day+=14;
    if(day>30){
        month++;
        day-=30;
    }
    if(month>12){
        year++;
        month=1;

    }
    *d=day;
    *m=month;
    *y=year;
    }

int dateCompare(char*date1,char*date2)
{
    int flag,d1,d2,m1,m2,y1,y2;

    sscanf(date1,"%d/%d/%d",&d1,&m1,&y1);
    sscanf(date2,"%d/%d/%d",&d2,&m2,&y2);

    if(y1>y2)
        return 1;
    else if(y2>y1)
        return 2;
    else if(m1>m2)
        return 1;
    else if(m2>m1)
        return 2;
    else if(d1>d2)
        return 1;
    else if(d2>d1)
        return 2;
    else
        return 0;


}























































