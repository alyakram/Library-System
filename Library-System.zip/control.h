#ifndef CONTROL_H
#define CONTROL_H
#include <stdio.h>

typedef struct
{
    int Day;
    int Month;
    int Year;
} Dat;
typedef struct
{
    char *Tittle;
    char *Author;
    char *Publisher;
    char ISBN[14];
    Dat DateOFPublishing;
    int NumberOFCopies;
    int AvalibaleNumberOfCopies;
    char *Category;
} Book;

typedef struct
{
    char *Bulding;
    char *Street;
    char *City;
} Address;
typedef struct
{
    char *FirstName;
    char *Lastname;
    int ID;
    Address memberAddress;
    char Phone[12];
    int Age;
    char* Email;
} MemberInf;
typedef struct{
char borrowBook[14];
int borrowID;
Dat borrowingDat;
Dat dueDat;
Dat returningDat;

}borrowingInf;
typedef struct{
char isbn[14];
int numberOfBorrows;
}Popular;

void insertBook();
void searchForBook();
void addCopies();
int bookLinesCounter();
void deleteBook();
void editBook();
void borrowBook();
void readFile();
int memberLinesCounter();
void readMembersFile();
void registerMember();
int borrowingLinesCounter();
void readBorrowingFile();
char*lowerString(char*,char*);
char*isbnValidity(char*);
int isbnLocation(char*);
void dateAdding(char*,int*,int*,int*);
void save(int);
void popular();
void overDue();
void returnBook();
void removeMember();
int dateCompare(char*,char*);


int booklines,memberLines,borrowLines;
Book *books;
Book *bookArray;
MemberInf *memberArray;
borrowingInf *borrowingArray;

#endif // CONTROL_H
