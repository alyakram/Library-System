#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "view.h"

int main()
{
    readFile();
    readMembersFile();
    readBorrowingFile();
    mainMenu();

     return 0;
   }
